//
//  User.swift
//  DesafioTableView
//
//  Created by Renato Vieira on 31/07/24.
//

import Foundation

struct User: Equatable {
    let name: String
    let career: String
}
